import React from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import { Search, FileText, Heart, Bell, Menu } from 'lucide-react'

const navItems = [
  { id: 'search', label: 'Buscar', icon: Search, path: '/dashboard/search' },
  { id: 'applications', label: 'Postulaciones', icon: FileText, path: '/dashboard/applications' },
  { id: 'favorites', label: 'Favoritos', icon: Heart, path: '/dashboard/favorites' },
  { id: 'alerts', label: 'Alertas', icon: Bell, path: '/dashboard/alerts' },
  { id: 'menu', label: 'Menú', icon: Menu, path: '/dashboard/menu' },
]

export default function BottomNavigation() {
  const location = useLocation()
  const navigate = useNavigate()

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 px-4 py-2">
      <div className="flex justify-around">
        {navItems.map((item) => {
          const Icon = item.icon
          const isActive = location.pathname === item.path || 
            (item.path === '/dashboard/search' && location.pathname === '/dashboard')
          
          return (
            <button
              key={item.id}
              onClick={() => navigate(item.path)}
              className={`nav-item ${isActive ? 'active' : ''}`}
            >
              <Icon className="w-6 h-6 mb-1" />
              <span>{item.label}</span>
            </button>
          )
        })}
      </div>
    </div>
  )
}
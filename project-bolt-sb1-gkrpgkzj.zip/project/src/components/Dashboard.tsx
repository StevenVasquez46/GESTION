import React from 'react'
import { Routes, Route } from 'react-router-dom'
import BottomNavigation from './BottomNavigation'
import SearchPage from './pages/SearchPage'
import ApplicationsPage from './pages/ApplicationsPage'
import FavoritesPage from './pages/FavoritesPage'
import AlertsPage from './pages/AlertsPage'
import MenuPage from './pages/MenuPage'

export default function Dashboard() {
  return (
    <div className="min-h-screen bg-gray-50 pb-20">
      <Routes>
        <Route path="/" element={<SearchPage />} />
        <Route path="/search" element={<SearchPage />} />
        <Route path="/applications" element={<ApplicationsPage />} />
        <Route path="/favorites" element={<FavoritesPage />} />
        <Route path="/alerts" element={<AlertsPage />} />
        <Route path="/menu" element={<MenuPage />} />
      </Routes>
      <BottomNavigation />
    </div>
  )
}
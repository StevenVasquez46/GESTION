import React from 'react'
import { Heart, MapPin, Clock, DollarSign } from 'lucide-react'

const favoriteJobs = [
  {
    id: 1,
    title: 'Desarrollador Frontend React',
    company: 'TechCorp México',
    location: 'Guadalajara, Jalisco',
    type: 'Remoto • Tiempo completo',
    experience: '3-5 años',
    salary: '$30,000 - $45,000 pesos mexicanos',
    tags: ['Relacional', 'Mercadotecnia', 'NextJs', 'Venta de cola'],
    savedDate: 'Hace 1 día'
  }
]

export default function FavoritesPage() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-primary-600 text-white px-4 py-6">
        <div className="flex items-center justify-between">
          <h1 className="text-xl font-semibold">Favoritos</h1>
          <span className="text-sm opacity-90">11:58</span>
        </div>
      </div>

      {/* Contenido */}
      <div className="px-4 py-6">
        <div className="mb-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-2">Mis trabajos favoritos</h2>
          <p className="text-gray-600 text-sm">1 oferta guardada</p>
        </div>

        {/* Lista de favoritos */}
        <div className="space-y-4">
          {favoriteJobs.map((job) => (
            <div key={job.id} className="card">
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center space-x-3">
                  <div className="w-12 h-12 bg-primary-600 rounded-lg flex items-center justify-center text-white font-bold text-lg">
                    TC
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900">{job.title}</h3>
                    <p className="text-primary-600 text-sm">{job.company}</p>
                  </div>
                </div>
                <button className="p-2 text-red-500 hover:bg-red-50 rounded-lg transition-colors">
                  <Heart className="w-6 h-6 fill-current" />
                </button>
              </div>

              <div className="space-y-2 mb-4">
                <div className="flex items-center text-gray-600 text-sm">
                  <MapPin className="w-4 h-4 mr-2" />
                  {job.location}
                </div>
                <div className="flex items-center text-gray-600 text-sm">
                  <Clock className="w-4 h-4 mr-2" />
                  {job.type}
                </div>
                <div className="flex items-center text-gray-600 text-sm">
                  <span className="mr-2">📅</span>
                  Experiencia: {job.experience}
                </div>
              </div>

              {/* Salario */}
              <div className="bg-green-50 border border-green-200 rounded-lg p-3 mb-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">Salario mensual</p>
                    <p className="font-semibold text-green-700">{job.salary}</p>
                  </div>
                  <DollarSign className="w-6 h-6 text-green-600" />
                </div>
              </div>

              {/* Tags */}
              <div className="mb-4">
                <div className="flex flex-wrap gap-2">
                  {job.tags.map((tag, index) => (
                    <span
                      key={index}
                      className="px-3 py-1 bg-gray-100 text-gray-700 text-sm rounded-full"
                    >
                      {tag}
                    </span>
                  ))}
                </div>
              </div>

              {/* Botones de acción */}
              <div className="flex space-x-3">
                <button className="btn-primary flex-1">
                  Ver detalles
                </button>
                <button className="btn-secondary flex-1">
                  Postularme
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Sección de búsqueda adicional */}
        <div className="mt-8 text-center">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-primary-100 rounded-full mb-4">
            <Heart className="w-8 h-8 text-primary-600" />
          </div>
          <h3 className="text-lg font-semibold text-gray-900 mb-2">¿Buscas más oportunidades?</h3>
          <p className="text-gray-600 mb-4">Explora nuevas ofertas y agrega tus favoritos.</p>
          <button className="btn-primary">
            Buscar trabajos
          </button>
        </div>
      </div>
    </div>
  )
}
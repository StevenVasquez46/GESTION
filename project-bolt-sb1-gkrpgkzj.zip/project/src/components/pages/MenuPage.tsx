import React from 'react'
import { User, Settings, FileText, Bell, Heart, HelpCircle, LogOut, ChevronRight } from 'lucide-react'
import { useAuth } from '../../context/AuthContext'

const menuItems = [
  { icon: User, label: 'Mi Perfil', description: 'Información personal y CV' },
  { icon: FileText, label: 'Mis Postulaciones', description: 'Historial de aplicaciones' },
  { icon: Heart, label: 'Trabajos Guardados', description: 'Ofertas favoritas' },
  { icon: Bell, label: 'Notificaciones', description: 'Alertas y configuración' },
  { icon: Settings, label: 'Configuración', description: 'Preferencias de la app' },
  { icon: HelpCircle, label: 'Ayuda y Soporte', description: 'Centro de ayuda' },
]

export default function MenuPage() {
  const { user, logout } = useAuth()

  const handleLogout = () => {
    logout()
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-primary-600 text-white px-4 py-6">
        <div className="flex items-center justify-between">
          <h1 className="text-xl font-semibold">Menú</h1>
          <span className="text-sm opacity-90">11:58</span>
        </div>
      </div>

      {/* Perfil del usuario */}
      <div className="px-4 py-6 bg-white border-b border-gray-200">
        <div className="flex items-center space-x-4">
          <div className="w-16 h-16 bg-primary-100 rounded-full flex items-center justify-center">
            <User className="w-8 h-8 text-primary-600" />
          </div>
          <div>
            <h2 className="text-lg font-semibold text-gray-900">
              {user?.name || 'Usuario'}
            </h2>
            <p className="text-gray-600">{user?.email}</p>
            <p className="text-sm text-primary-600 mt-1">Ver y editar perfil</p>
          </div>
        </div>
      </div>

      {/* Opciones del menú */}
      <div className="px-4 py-6">
        <div className="space-y-2">
          {menuItems.map((item, index) => {
            const Icon = item.icon
            return (
              <button
                key={index}
                className="w-full p-4 bg-white rounded-lg border border-gray-200 hover:bg-gray-50 transition-colors text-left"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <div className="w-10 h-10 bg-gray-100 rounded-lg flex items-center justify-center">
                      <Icon className="w-5 h-5 text-gray-600" />
                    </div>
                    <div>
                      <h3 className="font-medium text-gray-900">{item.label}</h3>
                      <p className="text-sm text-gray-600">{item.description}</p>
                    </div>
                  </div>
                  <ChevronRight className="w-5 h-5 text-gray-400" />
                </div>
              </button>
            )
          })}
        </div>

        {/* Botón de cerrar sesión */}
        <div className="mt-8">
          <button
            onClick={handleLogout}
            className="w-full p-4 bg-white rounded-lg border border-red-200 hover:bg-red-50 transition-colors text-left"
          >
            <div className="flex items-center space-x-4">
              <div className="w-10 h-10 bg-red-100 rounded-lg flex items-center justify-center">
                <LogOut className="w-5 h-5 text-red-600" />
              </div>
              <div>
                <h3 className="font-medium text-red-900">Cerrar Sesión</h3>
                <p className="text-sm text-red-600">Salir de tu cuenta</p>
              </div>
            </div>
          </button>
        </div>

        {/* Información de la app */}
        <div className="mt-8 text-center">
          <p className="text-sm text-gray-500">Versión 1.0.0</p>
          <p className="text-xs text-gray-400 mt-1">
            © 2024 JobSearch App. Todos los derechos reservados.
          </p>
        </div>
      </div>
    </div>
  )
}
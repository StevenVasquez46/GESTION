import React from 'react'
import { Bell, Plus, Settings } from 'lucide-react'

const alerts = [
  {
    id: 1,
    title: 'Desarrollador React',
    description: 'Nuevas ofertas en Ciudad de México',
    frequency: 'Diario',
    active: true,
    count: 3
  },
  {
    id: 2,
    title: 'Diseñador UX/UI',
    description: 'Trabajos remotos disponibles',
    frequency: 'Semanal',
    active: false,
    count: 0
  }
]

export default function AlertsPage() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-primary-600 text-white px-4 py-6">
        <div className="flex items-center justify-between">
          <h1 className="text-xl font-semibold">Alertas</h1>
          <span className="text-sm opacity-90">11:58</span>
        </div>
      </div>

      {/* Contenido */}
      <div className="px-4 py-6">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-lg font-semibold text-gray-900">Mis alertas de trabajo</h2>
            <p className="text-gray-600 text-sm">Recibe notificaciones de nuevas ofertas</p>
          </div>
          <button className="p-2 bg-primary-600 text-white rounded-lg hover:bg-primary-700 transition-colors">
            <Plus className="w-6 h-6" />
          </button>
        </div>

        {/* Lista de alertas */}
        <div className="space-y-4">
          {alerts.map((alert) => (
            <div key={alert.id} className="card">
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center space-x-3">
                  <div className={`w-12 h-12 rounded-lg flex items-center justify-center ${
                    alert.active ? 'bg-primary-100' : 'bg-gray-100'
                  }`}>
                    <Bell className={`w-6 h-6 ${
                      alert.active ? 'text-primary-600' : 'text-gray-400'
                    }`} />
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900">{alert.title}</h3>
                    <p className="text-gray-600 text-sm">{alert.description}</p>
                    <p className="text-gray-500 text-xs mt-1">Frecuencia: {alert.frequency}</p>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  {alert.count > 0 && (
                    <span className="bg-red-500 text-white text-xs px-2 py-1 rounded-full">
                      {alert.count}
                    </span>
                  )}
                  <button className="p-2 text-gray-400 hover:text-gray-600 transition-colors">
                    <Settings className="w-5 h-5" />
                  </button>
                </div>
              </div>

              <div className="flex items-center justify-between">
                <span className={`text-sm font-medium ${
                  alert.active ? 'text-green-600' : 'text-gray-500'
                }`}>
                  {alert.active ? 'Activa' : 'Inactiva'}
                </span>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    className="sr-only peer"
                    checked={alert.active}
                    readOnly
                  />
                  <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-primary-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary-600"></div>
                </label>
              </div>
            </div>
          ))}
        </div>

        {/* Crear nueva alerta */}
        <div className="mt-8">
          <button className="w-full p-4 border-2 border-dashed border-gray-300 rounded-lg text-gray-600 hover:border-primary-300 hover:text-primary-600 transition-colors">
            <Plus className="w-6 h-6 mx-auto mb-2" />
            <span className="block font-medium">Crear nueva alerta</span>
            <span className="text-sm">Configura alertas personalizadas para recibir ofertas relevantes</span>
          </button>
        </div>

        {/* Información adicional */}
        <div className="mt-6 p-4 bg-blue-50 rounded-lg border border-blue-200">
          <div className="flex items-start space-x-3">
            <Bell className="w-6 h-6 text-blue-600 flex-shrink-0 mt-0.5" />
            <div>
              <h3 className="font-medium text-blue-900 mb-1">¿Cómo funcionan las alertas?</h3>
              <p className="text-sm text-blue-700">
                Recibirás notificaciones por email cuando haya nuevas ofertas que coincidan con tus criterios de búsqueda.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
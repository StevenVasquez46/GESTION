import React, { useState } from 'react'
import { Search, MapPin, Clock, DollarSign, Briefcase, CheckCircle } from 'lucide-react'

const jobAlerts = [
  {
    id: 1,
    title: 'Nueva oferta de trabajo',
    description: 'Hace 2 horas',
    isNew: true
  }
]

const jobListings = [
  {
    id: 1,
    title: 'Diseñador Web',
    company: 'Soluciones tecnológicas digitales',
    location: 'Ciudad de México, CDMX',
    salary: '$25,000 - $35,000 pesos mexicanos',
    type: 'Tiempo completo',
    experience: '2-4 años',
    modality: 'Modalidad: Híbrido (3 días oficina, 2 días remoto)',
    benefits: 'Beneficios: Seguro médico, vales de despensa',
    skills: ['HTML/CSS', 'JavaScript', 'Responsive', 'Figma', 'Adobe XD'],
    posted: 'Hace 1 día',
    match: 'Coincidencia perfecta',
    matchDescription: 'Esta oferta coincide con tus preferencias de búsqueda.'
  }
]

export default function SearchPage() {
  const [searchQuery, setSearchQuery] = useState('')

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header con logo */}
      <div className="bg-white px-4 py-6 text-center border-b border-gray-200">
        <div className="inline-flex items-center justify-center w-16 h-16 bg-primary-100 rounded-2xl mb-4">
          <div className="relative">
            <Briefcase className="w-8 h-8 text-primary-600" />
            <CheckCircle className="w-5 h-5 text-primary-600 absolute -bottom-1 -right-1 bg-white rounded-full" />
          </div>
        </div>
        <h1 className="text-xl font-semibold text-gray-900 mb-2">
          Conectando necesidades, generando oportunidades
        </h1>
        
        {/* Barra de búsqueda */}
        <div className="relative mt-4">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="¿Qué empleo buscas?"
            className="w-full pl-10 pr-4 py-3 bg-gray-100 border-0 rounded-lg focus:ring-2 focus:ring-primary-500 focus:bg-white outline-none transition-colors duration-200"
          />
        </div>

        {/* Notificación */}
        <div className="mt-4 p-3 bg-blue-50 rounded-lg border border-blue-200">
          <div className="flex items-start space-x-3">
            <div className="w-6 h-6 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
              <div className="w-2 h-2 bg-blue-600 rounded-full"></div>
            </div>
            <div className="text-left">
              <p className="text-sm text-gray-700 font-medium">
                Las notificaciones están desactivadas.
              </p>
              <p className="text-sm text-gray-600">
                Actívalas para no perder ninguna oportunidad.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Alertas */}
      <div className="px-4 py-4">
        <div className="bg-primary-600 text-white p-4 rounded-lg mb-4">
          <h2 className="font-semibold mb-2">Mis alertas</h2>
          {jobAlerts.map((alert) => (
            <div key={alert.id} className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="w-6 h-6 bg-primary-500 rounded-full flex items-center justify-center">
                  <div className="w-2 h-2 bg-white rounded-full"></div>
                </div>
                <div>
                  <p className="font-medium">{alert.title}</p>
                  <p className="text-primary-100 text-sm">{alert.description}</p>
                </div>
              </div>
              {alert.isNew && (
                <div className="w-3 h-3 bg-red-500 rounded-full"></div>
              )}
            </div>
          ))}
        </div>

        {/* Lista de trabajos */}
        <div className="space-y-4">
          {jobListings.map((job) => (
            <div key={job.id} className="card">
              {/* Header del trabajo */}
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center space-x-3">
                  <div className="w-12 h-12 bg-primary-600 rounded-lg flex items-center justify-center text-white font-bold text-lg">
                    DT
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900">{job.title}</h3>
                    <p className="text-primary-600 text-sm">{job.company}</p>
                  </div>
                </div>
              </div>

              {/* Detalles del trabajo */}
              <div className="space-y-2 mb-4">
                <div className="flex items-center text-gray-600 text-sm">
                  <MapPin className="w-4 h-4 mr-2" />
                  {job.location}
                </div>
                <div className="flex items-center text-gray-600 text-sm">
                  <Clock className="w-4 h-4 mr-2" />
                  {job.type}
                </div>
                <div className="flex items-center text-gray-600 text-sm">
                  <span className="mr-2">📅</span>
                  Experiencia: {job.experience}
                </div>
                <div className="text-gray-600 text-sm">
                  <span className="mr-2">🏢</span>
                  {job.modality}
                </div>
                <div className="text-gray-600 text-sm">
                  <span className="mr-2">💼</span>
                  {job.benefits}
                </div>
              </div>

              {/* Salario */}
              <div className="bg-green-50 border border-green-200 rounded-lg p-3 mb-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">Salario mensual</p>
                    <p className="font-semibold text-green-700">{job.salary}</p>
                  </div>
                  <DollarSign className="w-6 h-6 text-green-600" />
                </div>
              </div>

              {/* Habilidades */}
              <div className="mb-4">
                <p className="text-sm font-medium text-gray-700 mb-2">Habilidades requeridas:</p>
                <div className="flex flex-wrap gap-2">
                  {job.skills.map((skill, index) => (
                    <span
                      key={index}
                      className="px-3 py-1 bg-gray-100 text-gray-700 text-sm rounded-full"
                    >
                      {skill}
                    </span>
                  ))}
                </div>
              </div>

              {/* Botones de acción */}
              <div className="flex space-x-3">
                <button className="btn-primary flex-1">
                  Ver detalles
                </button>
                <button className="btn-secondary flex-1">
                  Postularme
                </button>
              </div>

              {/* Coincidencia */}
              <div className="mt-4 p-3 bg-blue-50 rounded-lg border border-blue-200">
                <div className="flex items-center space-x-2">
                  <div className="w-6 h-6 bg-blue-100 rounded-full flex items-center justify-center">
                    <CheckCircle className="w-4 h-4 text-blue-600" />
                  </div>
                  <div>
                    <p className="font-medium text-blue-900">{job.match}</p>
                    <p className="text-sm text-blue-700">{job.matchDescription}</p>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
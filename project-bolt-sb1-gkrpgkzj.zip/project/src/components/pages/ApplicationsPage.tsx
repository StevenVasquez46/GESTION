import React from 'react'
import { Clock, MapPin, DollarSign } from 'lucide-react'

const applications = [
  {
    id: 1,
    title: 'Desarrollador Frontend React',
    company: 'TechCorp México',
    location: 'Guadalajara, Jalisco',
    salary: '$30,000 - $45,000 MXN',
    appliedDate: 'Aplicado hace 3 días',
    status: 'En revisión',
    statusColor: 'bg-yellow-100 text-yellow-800'
  },
  {
    id: 2,
    title: 'Diseñador UX/UI Senior',
    company: 'Estudio creativo',
    location: 'Ciudad de México, CDMX',
    salary: '$35,000 - $50,000 MXN',
    appliedDate: 'Aplicado hace 1 semana',
    status: 'Aceptado',
    statusColor: 'bg-green-100 text-green-800'
  }
]

const stats = [
  { number: '2', label: 'Total' },
  { number: '1', label: 'Aceptadas' },
  { number: '1', label: 'En revisión' }
]

export default function ApplicationsPage() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-primary-600 text-white px-4 py-6">
        <div className="flex items-center justify-between mb-4">
          <h1 className="text-xl font-semibold">Mis postulaciones</h1>
          <span className="text-sm opacity-90">11:58</span>
        </div>
        
        {/* Estadísticas */}
        <div className="grid grid-cols-3 gap-4">
          {stats.map((stat, index) => (
            <div key={index} className="bg-white/10 rounded-lg p-4 text-center">
              <div className="text-2xl font-bold">{stat.number}</div>
              <div className="text-sm opacity-90">{stat.label}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Contenido */}
      <div className="px-4 py-6">
        <div className="mb-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-2">Mis aplicaciones</h2>
          <p className="text-gray-600 text-sm">Historial de postulaciones enviadas</p>
        </div>

        {/* Lista de aplicaciones */}
        <div className="space-y-4">
          {applications.map((app) => (
            <div key={app.id} className="card">
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center space-x-3">
                  <div className="w-12 h-12 bg-primary-600 rounded-lg flex items-center justify-center text-white font-bold text-lg">
                    {app.title.charAt(0)}
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900">{app.title}</h3>
                    <p className="text-primary-600 text-sm">{app.company}</p>
                  </div>
                </div>
                <span className={`px-3 py-1 rounded-full text-xs font-medium ${app.statusColor}`}>
                  {app.status}
                </span>
              </div>

              <div className="space-y-2 mb-4">
                <div className="flex items-center text-gray-600 text-sm">
                  <MapPin className="w-4 h-4 mr-2" />
                  {app.location}
                </div>
                <div className="flex items-center text-gray-600 text-sm">
                  <DollarSign className="w-4 h-4 mr-2" />
                  Salario: {app.salary}
                </div>
                <div className="flex items-center text-gray-600 text-sm">
                  <Clock className="w-4 h-4 mr-2" />
                  {app.appliedDate}
                </div>
              </div>

              <div className="flex space-x-3">
                <button className="btn-primary flex-1">
                  Ver detalles
                </button>
                <button className="btn-secondary flex-1">
                  {app.status === 'Aceptado' ? 'Ver oferta' : 'Retirar aplicación'}
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Sección de búsqueda adicional */}
        <div className="mt-8 text-center">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-primary-100 rounded-full mb-4">
            <div className="w-8 h-8 text-primary-600">📤</div>
          </div>
          <h3 className="text-lg font-semibold text-gray-900 mb-2">¿Buscas más oportunidades?</h3>
          <p className="text-gray-600 mb-4">Encuentra nuevas ofertas de trabajo y agrega tus favoritos.</p>
          <button className="btn-primary">
            Buscar trabajos
          </button>
        </div>
      </div>
    </div>
  )
}